local Core = nil

CreateThread(function()
    if R.Framework == "ESX" then
        if R.newESX then
            Core = exports[R.CoreName]:getSharedObject()
        else
            while Core == nil do
                TriggerEvent("esx:getSharedObject", function(obj) Core = obj end)
                Wait(100)
            end
        end
    else
        Core = exports["qb-core"]:GetCoreObject()
    end
end)

if R.EnableAutoinsert then
    CreateThread(function()
        Wait(1000)
        MySQL.Async.execute([[
            CREATE TABLE IF NOT EXISTS `r_store_coins` (
                `identifier` VARCHAR(60) NOT NULL,
                `coins` INT(11) NOT NULL DEFAULT 0,
                `last_case_cooldown` DATETIME NULL,
                `total_winnings` BIGINT(20) NOT NULL DEFAULT 0,
                `total_losses` BIGINT(20) NOT NULL DEFAULT 0,
                `total_cases_opened` INT(11) NOT NULL DEFAULT 0,
                `total_coinflips_won` INT(11) NOT NULL DEFAULT 0,
                `total_coinflips_lost` INT(11) NOT NULL DEFAULT 0,
                `total_mines_won` INT(11) NOT NULL DEFAULT 0,
                `total_mines_lost` INT(11) NOT NULL DEFAULT 0,
                `total_tower_won` INT(11) NOT NULL DEFAULT 0,
                `total_tower_lost` INT(11) NOT NULL DEFAULT 0,
                `total_keno_won` INT(11) NOT NULL DEFAULT 0,
                `total_keno_lost` INT(11) NOT NULL DEFAULT 0,
                `total_dice_won` INT(11) NOT NULL DEFAULT 0,
                `total_dice_lost` INT(11) NOT NULL DEFAULT 0,
                PRIMARY KEY (`identifier`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ]], {})
        
        if R.Debug then
            print("^2[r_store]^7 Database table initialized")
        end
    end)
end

function GetPlayerIdentifier(src)
    local identifier = nil
    
    if R.Framework == "ESX" then
        local xPlayer = Core.GetPlayerFromId(src)
        if xPlayer then
            identifier = xPlayer.identifier
        end
    else
        local Player = Core.Functions.GetPlayer(src)
        if Player then
            identifier = Player.PlayerData.citizenid
        end
    end
    
    return identifier
end

function GetPlayerName(src)
    local name = nil
    
    if R.Framework == "ESX" then
        local xPlayer = Core.GetPlayerFromId(src)
        if xPlayer then
            name = xPlayer.getName()
        end
    else
        local Player = Core.Functions.GetPlayer(src)
        if Player then
            name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
        end
    end
    
    return name or "Unknown"
end

function LogAction(src, action, data)
    if not R.Enablelogs then return end
    
    local identifier = GetPlayerIdentifier(src)
    local playerName = GetPlayerName(src)
    
    print(string.format("^3[r_store]^7 [%s] %s (%s) - %s", os.date("%Y-%m-%d %H:%M:%S"), playerName, identifier, action))
    if data then
        print("^3[r_store]^7 Data: " .. json.encode(data))
    end
end

lib.callback.register("r_store:checkAndRegisterPlayer", function(source)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return false end
    
    local result = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    })
    
    if not result then
        MySQL.Async.execute("INSERT INTO r_store_coins (identifier, coins) VALUES (@identifier, 0)", {
            ['@identifier'] = identifier
        })
        
        if R.Debug then
            print("^2[r_store]^7 Registered new player: " .. identifier)
        end
    end
    
    return true
end)

lib.callback.register("r_store:getPlayerCoinBalance", function(source)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return 0 end
    
    local coins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    })
    
    return coins or 0
end)

lib.callback.register("r_store:removeCoinsFromPlayer", function(source, amount)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return false end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins >= amount then
        MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount WHERE identifier = @identifier", {
            ['@identifier'] = identifier,
            ['@amount'] = amount
        })
        
        LogAction(source, "Removed coins", { amount = amount, remaining = currentCoins - amount })
        return true
    end
    
    return false
end)

lib.callback.register("r_store:addItemsToPlayer", function(source, items)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then 
        if R.Debug then
            print("^1[r_store]^7 Failed to get identifier for player: " .. source)
        end
        return false 
    end
    
    local itemName = items.value or nil
    if not itemName then
        if R.Debug then
            print("^1[r_store]^7 No item name found in items table")
        end
        return false
    end
    
    if R.Debug then
        print("^3[r_store]^7 Adding items - Item: " .. tostring(itemName) .. " Type: " .. tostring(items.type) .. " Amount: " .. tostring(items.amount))
        print("^3[r_store]^7 Full items table: " .. json.encode(items))
    end
    
    local success = false
    if items.type == "vehicle" then
        playerid = Core.GetPlayerFromId(source)

        ExecuteCommand("_givecar" .. playerid .. items.value)
        if R.Debug then
            print("^1[r_store]^7 Vehicle purchase not handled in addItemsToPlayer")
        end
        return false
    end
    if items.type == "money" then
        local xPlayer = Core.GetPlayerFromId(source)
        if xPlayer then
            xPlayer.addMoney(items.value)
            success = true
        end
    end
    
    if R.Inventory == "ox_inventory" then
        local result = nil
        
        if exports['ox_inventory'] and exports['ox_inventory'].AddItem then
            if items.metadata then
                result = exports['ox_inventory']:AddItem(source, itemName, items.amount, items.metadata)
            else
                result = exports['ox_inventory']:AddItem(source, itemName, items.amount)
            end
            
            success = result ~= nil and result ~= false and (type(result) == "number" or result == true)
            
            if R.Debug then
                print("^3[r_store]^7 ox_inventory AddItem result: " .. tostring(result) .. " Success: " .. tostring(success))
            end
            
            if not success and exports['ox_inventory'].CanCarryItem then
                local canCarry = exports['ox_inventory']:CanCarryItem(source, itemName, items.amount)
                if R.Debug then
                    print("^3[r_store]^7 CanCarryItem result: " .. tostring(canCarry))
                end
                if canCarry then
                    result = exports['ox_inventory']:AddItem(source, itemName, items.amount)
                    success = result ~= nil and result ~= false
                else
                    if R.Debug then
                        print("^1[r_store]^7 Player cannot carry this item (inventory full or item doesn't exist)")
                    end
                end
            end
        else
            if R.Debug then
                print("^1[r_store]^7 ox_inventory export not found or AddItem function doesn't exist")
            end
        end
    elseif R.Inventory == "ESX" then
        local xPlayer = Core.GetPlayerFromId(source)
        if xPlayer then
            if items.type == "item" or not items.type then
                xPlayer.addInventoryItem(itemName, items.amount)
                success = true
            elseif items.type == "weapon" then
                xPlayer.addWeapon(itemName, items.amount or 100)
                success = true
            end
        else
            if R.Debug then
                print("^1[r_store]^7 Failed to get ESX player: " .. source)
            end
        end
    elseif R.Inventory == "qb-inventory" or R.Inventory == "quasar" then
        local Player = Core.Functions.GetPlayer(source)
        if Player then
            Player.Functions.AddItem(itemName, items.amount)
            TriggerClientEvent('inventory:client:ItemBox', source, Core.Shared.Items[itemName], "add")
            success = true
        end
    end
    
    if success then
        LogAction(source, "Added items", { item = itemName, amount = items.amount, type = items.type or "item" })
        
        if R.EnablePurchaseNotifys then
            if R.Framework == "ESX" then
                TriggerClientEvent('esx:showNotification', source, string.format("Purchased %dx %s", items.amount, itemName))
            else
                TriggerClientEvent('QBCore:Notify', source, string.format("Purchased %dx %s", items.amount, itemName), "success")
            end
        end
    else
        if R.Debug then
            print("^1[r_store]^7 Failed to add item: " .. tostring(itemName) .. " to player: " .. source)
        end
        LogAction(source, "Failed to add items", { item = itemName, amount = items.amount, type = items.type or "item" })
        
        if R.Framework == "ESX" then
            TriggerClientEvent('esx:showNotification', source, "Failed to add item to inventory. Check if item exists and inventory space.", "error")
        else
            TriggerClientEvent('QBCore:Notify', source, "Failed to add item to inventory. Check if item exists and inventory space.", "error")
        end
    end
    
    return success
end)

lib.callback.register("r_store:removeCaseCoins", function(source, casePrice, requiredRole, caseValue, cooldownHours)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    if cooldownHours and cooldownHours > 0 then
        local result = MySQL.Sync.fetchScalar("SELECT last_case_cooldown FROM r_store_coins WHERE identifier = @identifier", {
            ['@identifier'] = identifier
        })
        
        if result then
            local cooldownTime = os.time() - (cooldownHours * 3600)
            local lastCooldown = os.time({year = string.sub(result, 1, 4), month = string.sub(result, 6, 7), day = string.sub(result, 9, 10), hour = string.sub(result, 12, 13), min = string.sub(result, 15, 16), sec = string.sub(result, 18, 19)})
            
            if lastCooldown > cooldownTime then
                return { success = false, message = "Case cooldown active" }
            end
        end
    end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < casePrice then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, last_case_cooldown = NOW() WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = casePrice
    })
    
    local newCoins = currentCoins - casePrice
    LogAction(source, "Removed case coins", { amount = casePrice, case_value = caseValue })
    
    return { success = true, coins = newCoins }
end)

lib.callback.register("r_store:giveOpenCaseReward", function(source, wonItem)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    MySQL.Async.execute("UPDATE r_store_coins SET total_cases_opened = total_cases_opened + 1 WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    })
    
    if wonItem.type == "item" then
        if R.Inventory == "ox_inventory" then
            exports.ox_inventory:AddItem(source, wonItem.name, wonItem.amount or 1, wonItem.metadata or {})
        elseif R.Inventory == "ESX" then
            local xPlayer = Core.GetPlayerFromId(source)
            if xPlayer then
                xPlayer.addInventoryItem(wonItem.name, wonItem.amount or 1)
            end
        elseif R.Inventory == "qb-inventory" or R.Inventory == "quasar" then
            local Player = Core.Functions.GetPlayer(source)
            if Player then
                Player.Functions.AddItem(wonItem.name, wonItem.amount or 1)
                TriggerClientEvent('inventory:client:ItemBox', source, Core.Shared.Items[wonItem.name], "add")
            end
        end
    elseif wonItem.type == "coins" then
        local coinAmount = wonItem.amount or wonItem.value or 0
        MySQL.Async.execute("UPDATE r_store_coins SET coins = coins + @amount, total_winnings = total_winnings + @amount WHERE identifier = @identifier", {
            ['@identifier'] = identifier,
            ['@amount'] = coinAmount
        })
    end
    
    LogAction(source, "Case reward given", { item = wonItem.name, type = wonItem.type, amount = wonItem.amount or wonItem.value })
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    return { success = true, coins = newCoins }
end)

lib.callback.register("r_store:removeCoinflipBet", function(source, betAmount)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < betAmount then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, total_losses = total_losses + @amount WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = betAmount
    })
    
    local newCoins = currentCoins - betAmount
    LogAction(source, "Coinflip bet placed", { amount = betAmount })
    
    return { success = true, coins = newCoins }
end)

lib.callback.register("r_store:giveCoinflipWinnings", function(source, betAmount)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local winnings = betAmount * 2
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins + @winnings, total_winnings = total_winnings + @winnings, total_coinflips_won = total_coinflips_won + 1 WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@winnings'] = winnings
    })
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    LogAction(source, "Coinflip won", { bet = betAmount, winnings = winnings })
    
    return { success = true, coins = newCoins }
end)

lib.callback.register("r_store:startMinesGame", function(source, betAmount, mineCount)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < betAmount then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, total_losses = total_losses + @amount, total_mines_lost = total_mines_lost + 1 WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = betAmount
    })
    
    local newCoins = currentCoins - betAmount
    LogAction(source, "Mines game started", { bet = betAmount, mines = mineCount })
    
    return { success = true, coins = newCoins }
end)

lib.callback.register("r_store:cashoutMines", function(source, betAmount, multiplier, revealedCount)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local winnings = math.floor(betAmount * multiplier)
    
    MySQL.Async.execute([[
        UPDATE r_store_coins 
        SET coins = coins + @winnings, 
            total_winnings = total_winnings + @winnings, 
            total_losses = GREATEST(0, total_losses - @betAmount),
            total_mines_won = total_mines_won + 1, 
            total_mines_lost = GREATEST(0, total_mines_lost - 1)
        WHERE identifier = @identifier
    ]], {
        ['@identifier'] = identifier,
        ['@winnings'] = winnings,
        ['@betAmount'] = betAmount
    })
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    LogAction(source, "Mines cashed out", { bet = betAmount, multiplier = multiplier, winnings = winnings })
    
    return { success = true, coins = newCoins, winnings = winnings }
end)
lib.callback.register("r_store:startTowerGame", function(source, betAmount, difficulty)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < betAmount then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, total_losses = total_losses + @amount, total_tower_lost = total_tower_lost + 1 WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = betAmount
    })
    
    local newCoins = currentCoins - betAmount
    
    local eggPositions = {}
    for i = 1, 3 do
        eggPositions[i] = math.random(1, 4)
    end
    
    LogAction(source, "Tower game started", { bet = betAmount, difficulty = difficulty })
    
    return { success = true, coins = newCoins, eggPositions = eggPositions }
end)

lib.callback.register("r_store:cashoutTower", function(source, betAmount, multiplier)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local winnings = math.floor(betAmount * multiplier)
    
    MySQL.Async.execute([[
        UPDATE r_store_coins 
        SET coins = coins + @winnings, 
            total_winnings = total_winnings + @winnings, 
            total_losses = GREATEST(0, total_losses - @betAmount),
            total_tower_won = total_tower_won + 1, 
            total_tower_lost = GREATEST(0, total_tower_lost - 1)
        WHERE identifier = @identifier
    ]], {
        ['@identifier'] = identifier,
        ['@winnings'] = winnings,
        ['@betAmount'] = betAmount
    })
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    LogAction(source, "Tower cashed out", { bet = betAmount, multiplier = multiplier, winnings = winnings })
    
    return { success = true, coins = newCoins, winnings = winnings }
end)

lib.callback.register("r_store:getLeaderboard", function(source, category)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return {} end
    
    local query = ""
    
    if category == "winnings" then
        query = "SELECT identifier, total_winnings as value FROM r_store_coins ORDER BY total_winnings DESC LIMIT 10"
    elseif category == "cases" then
        query = "SELECT identifier, total_cases_opened as value FROM r_store_coins ORDER BY total_cases_opened DESC LIMIT 10"
    elseif category == "coinflips" then
        query = "SELECT identifier, total_coinflips_won as value FROM r_store_coins ORDER BY total_coinflips_won DESC LIMIT 10"
    elseif category == "mines" then
        query = "SELECT identifier, total_mines_won as value FROM r_store_coins ORDER BY total_mines_won DESC LIMIT 10"
    elseif category == "tower" then
        query = "SELECT identifier, total_tower_won as value FROM r_store_coins ORDER BY total_tower_won DESC LIMIT 10"
    elseif category == "keno" then
        query = "SELECT identifier, total_keno_won as value FROM r_store_coins ORDER BY total_keno_won DESC LIMIT 10"
    elseif category == "dice" then
        query = "SELECT identifier, total_dice_won as value FROM r_store_coins ORDER BY total_dice_won DESC LIMIT 10"
    else
        return {}
    end
    
    local results = MySQL.Sync.fetchAll(query, {})
    
    local leaderboard = {}
    for i, row in ipairs(results) do
        local playerName = "Unknown"
        
        local found = false
        if R.Framework == "ESX" then
            local players = Core.GetPlayers()
            for _, playerId in ipairs(players) do
                local xPlayer = Core.GetPlayerFromId(playerId)
                if xPlayer and xPlayer.identifier == row.identifier then
                    playerName = xPlayer.getName()
                    found = true
                    break
                end
            end
        else
            local players = Core.Functions.GetPlayers()
            for _, playerId in ipairs(players) do
                local Player = Core.Functions.GetPlayer(playerId)
                if Player and Player.PlayerData.citizenid == row.identifier then
                    playerName = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
                    found = true
                    break
                end
            end
        end
        
        if not found and R.Framework == "ESX" then
            local result = MySQL.Sync.fetchScalar("SELECT firstname, lastname FROM users WHERE identifier = @identifier LIMIT 1", {
                ['@identifier'] = row.identifier
            })
            if result then
            end
        end
        
        table.insert(leaderboard, {
            rank = i,
            identifier = row.identifier,
            name = playerName,
            value = row.value or 0
        })
    end
    
    return leaderboard
end)

lib.callback.register("r_store:playkeno", function(source, betAmount, selectedNumbers)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < betAmount then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, total_losses = total_losses + @amount WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = betAmount
    })
    
    local drawnNumbers = {}
    local drawnSet = {}
    
    while #drawnNumbers < 20 do
        local num = math.random(1, 80)
        if not drawnSet[num] then
            drawnSet[num] = true
            table.insert(drawnNumbers, num)
        end
    end
    
    table.sort(drawnNumbers)
    
    local hits = 0
    local selectedSet = {}
    for _, num in ipairs(selectedNumbers) do
        selectedSet[num] = true
    end
    
    for _, num in ipairs(drawnNumbers) do
        if selectedSet[num] then
            hits = hits + 1
        end
    end
    
    local winnings = 0
    local payoutMultiplier = {
        [0] = 0,
        [1] = 0,
        [2] = 0,
        [3] = 1.5,
        [4] = 2,
        [5] = 3,
        [6] = 5,
        [7] = 10,
        [8] = 25,
        [9] = 50,
        [10] = 100
    }
    
    if hits >= 3 then
        winnings = math.floor(betAmount * (payoutMultiplier[hits] or 0))
        
        if winnings > 0 then
            MySQL.Async.execute("UPDATE r_store_coins SET coins = coins + @winnings, total_winnings = total_winnings + @winnings, total_keno_won = total_keno_won + 1 WHERE identifier = @identifier", {
                ['@identifier'] = identifier,
                ['@winnings'] = winnings
            })
        else
            MySQL.Async.execute("UPDATE r_store_coins SET total_keno_lost = total_keno_lost + 1 WHERE identifier = @identifier", {
                ['@identifier'] = identifier
            })
        end
    else
        MySQL.Async.execute("UPDATE r_store_coins SET total_keno_lost = total_keno_lost + 1 WHERE identifier = @identifier", {
            ['@identifier'] = identifier
        })
    end
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    LogAction(source, "Keno played", { bet = betAmount, hits = hits, winnings = winnings })
    
    return { 
        success = true, 
        coins = newCoins, 
        drawnNumbers = drawnNumbers, 
        hits = hits, 
        winnings = winnings 
    }
end)

lib.callback.register("r_store:playdice", function(source, betAmount, predictionType, target)
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return { success = false, message = "Invalid player" } end
    
    local currentCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    if currentCoins < betAmount then
        return { success = false, message = "Not enough coins" }
    end
    
    MySQL.Async.execute("UPDATE r_store_coins SET coins = coins - @amount, total_losses = total_losses + @amount WHERE identifier = @identifier", {
        ['@identifier'] = identifier,
        ['@amount'] = betAmount
    })
    
    local dice1 = math.random(1, 6)
    local dice2 = math.random(1, 6)
    local sum = dice1 + dice2
    
    local won = false
    local winnings = 0
    
    if predictionType == "sum" then
        won = (sum == target)
        if won then
            winnings = math.floor(betAmount * 6)
        end
    elseif predictionType == "higher" then
        won = (sum > target)
        if won then
            winnings = math.floor(betAmount * 2)
        end
    elseif predictionType == "lower" then
        won = (sum < target)
        if won then
            winnings = math.floor(betAmount * 2)
        end
    elseif predictionType == "even" then
        won = (sum % 2 == 0)
        if won then
            winnings = math.floor(betAmount * 2)
        end
    elseif predictionType == "odd" then
        won = (sum % 2 == 1)
        if won then
            winnings = math.floor(betAmount * 2)
        end
    end
    
    if won and winnings > 0 then
        MySQL.Async.execute("UPDATE r_store_coins SET coins = coins + @winnings, total_winnings = total_winnings + @winnings, total_dice_won = total_dice_won + 1 WHERE identifier = @identifier", {
            ['@identifier'] = identifier,
            ['@winnings'] = winnings
        })
    else
        MySQL.Async.execute("UPDATE r_store_coins SET total_dice_lost = total_dice_lost + 1 WHERE identifier = @identifier", {
            ['@identifier'] = identifier
        })
    end
    
    local newCoins = MySQL.Sync.fetchScalar("SELECT coins FROM r_store_coins WHERE identifier = @identifier", {
        ['@identifier'] = identifier
    }) or 0
    
    LogAction(source, "Dice played", { bet = betAmount, prediction = predictionType, target = target, result = sum, won = won, winnings = winnings })
    
    return { 
        success = true, 
        coins = newCoins, 
        dice1 = dice1, 
        dice2 = dice2, 
        sum = sum, 
        won = won, 
        winnings = winnings 
    }
end)

RegisterCommand(R.GiveCreditCommand, function(source, args, rawCommand)
    if source == 0 then
        print("^1[r_store]^7 This command can only be used in-game")
        return
    end
    
    local identifier = GetPlayerIdentifier(source)
    if not identifier then return end
    
    if args[1] and args[2] then
        local targetId = tonumber(args[1])
        local amount = tonumber(args[2])
        
        if targetId and amount and amount > 0 then
            local targetIdentifier = GetPlayerIdentifier(targetId)
            if targetIdentifier then
                MySQL.Async.execute("UPDATE r_store_coins SET coins = coins + @amount WHERE identifier = @identifier", {
                    ['@identifier'] = targetIdentifier,
                    ['@amount'] = amount
                })
                
                LogAction(source, "Gave credits", { target = targetId, amount = amount })
                
                if R.Framework == "ESX" then
                    TriggerClientEvent('esx:showNotification', source, string.format("Gave %d credits to player %d", amount, targetId))
                    TriggerClientEvent('esx:showNotification', targetId, string.format("You received %d credits", amount))
                else
                    TriggerClientEvent('QBCore:Notify', source, string.format("Gave %d credits to player %d", amount, targetId), "success")
                    TriggerClientEvent('QBCore:Notify', targetId, string.format("You received %d credits", amount), "success")
                end
            else
                if R.Framework == "ESX" then
                    TriggerClientEvent('esx:showNotification', source, "Player not found", "error")
                else
                    TriggerClientEvent('QBCore:Notify', source, "Player not found", "error")
                end
            end
        else
            if R.Framework == "ESX" then
                TriggerClientEvent('esx:showNotification', source, "Usage: /" .. R.GiveCreditCommand .. " [playerid] [amount]", "error")
            else
                TriggerClientEvent('QBCore:Notify', source, "Usage: /" .. R.GiveCreditCommand .. " [playerid] [amount]", "error")
            end
        end
    else
        if R.Framework == "ESX" then
            TriggerClientEvent('esx:showNotification', source, "Usage: /" .. R.GiveCreditCommand .. " [playerid] [amount]", "error")
        else
            TriggerClientEvent('QBCore:Notify', source, "Usage: /" .. R.GiveCreditCommand .. " [playerid] [amount]", "error")
        end
    end
end, false)

