const vehiclesData = getVehiclesData();
const itemsDataPage2 = getItemsDataPage2();
const itemsDataPage3 = getItemsDataPage3();
const itemsDataPage4 = getItemsDataPage4();

let isPurchasing = false;

function setButtonLoading(buttonElement, isLoading, textKey, icon) {
  if (isLoading) {
    buttonElement.disabled = true;
    buttonElement.classList.add('loading');
    buttonElement.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> <span data-translate="${textKey}">${t(textKey)}</span>`;
  } else {
    buttonElement.disabled = false;
    buttonElement.classList.remove('loading');
    buttonElement.innerHTML = `<i class="fa-solid ${icon}"></i> <span data-translate="${textKey}">${t(textKey)}</span>`;
  }
}

function initializePages() {
  applyTranslations();
  
  populateContainer('page1', vehiclesData, false);
  populateContainer('page2', itemsDataPage2, true);
  populateContainer('page3', itemsDataPage3, true);
  populateContainer('page4', itemsDataPage4, true);
}

function applyTranslations() {
  document.querySelector("#btnPage1").innerHTML = `<i class="fas fa-car"></i> ${t("vehicles")}`;
  document.querySelector("#btnPage2").innerHTML = `<i class="fas fa-money-bill-wave"></i> ${t("money")}`;
  document.querySelector("#btnPage3").innerHTML = `<i class="fas fa-wrench"></i> ${t("items")}`;
  document.querySelector("#btnPage4").innerHTML = `<i class="fas fa-gun"></i> ${t("weapons")}`;
  document.querySelector("#searchInput").placeholder = t("search");
  document.querySelector("#purchase-button").innerHTML = `<i class="fa-solid fa-cart-arrow-down"></i> ${t("buy")}`;
  document.querySelector("#test-drive-button").innerHTML = `<i class="fas fa-car"></i> ${t("testDrive")}`;
  document.querySelector("#quantity").placeholder = t("amount");
}

document.addEventListener('DOMContentLoaded', initializePages);

function populateContainer(pageId, data, isItem) {
  const container = document.getElementById(pageId);
  container.innerHTML = '';

  const Div = document.createElement('div');
  Div.classList.add('vehicles');

  data.forEach(Data => {
    const Cont = createContainer(Data, isItem);
    Div.appendChild(Cont);
  });

  container.appendChild(Div);
}

function createContainer(vehicle, isItem) {
  const vehicleContainer = document.createElement('div');
  vehicleContainer.classList.add('vehicle-container');

  vehicleContainer.dataset.IsNew = vehicle.IsNew;
  vehicleContainer.dataset.IsSale = vehicle.IsSale;
  vehicleContainer.dataset.IsLimited = vehicle.IsLimited;

  const img = document.createElement('img');
  img.src = vehicle.image;
  img.alt = vehicle.name;

  if (isItem) {
    img.style.top = "-6px";
    img.style.maxWidth = "70%";
  };

  const vehicleName = document.createElement('h3');
  vehicleName.classList.add('vehicle-name');
  vehicleName.textContent = vehicle.name;

  const tagsContainer = document.createElement('div');
  tagsContainer.classList.add('tags-container');

  function appendTag(condition, className, text, iconClass) {
    if (condition) {
      const tag = document.createElement('span');
      tag.classList.add('tag', className);

      const icon = document.createElement('i');
      icon.classList.add('fas', iconClass);
      tag.appendChild(icon);

      const tagText = document.createTextNode(` ${text}`);
      tag.appendChild(tagText);

      tagsContainer.appendChild(tag);
    }
  }

  appendTag(vehicle.IsNew, 'new-tag', t('new_tag'), 'fa-star');
  appendTag(vehicle.IsSale, 'sale-tag', t('sale_tag'), 'fa-tag');
  appendTag(vehicle.IsLimited, 'limited-tag', t('limited_tag'), 'fa-clock');  

  const vehicleDetails = document.createElement('div');
  vehicleDetails.classList.add('details');

  const vehiclePrice = document.createElement('p');
  vehiclePrice.classList.add('price');
  vehiclePrice.textContent = `${vehicle.price.toLocaleString()} `;

  const coinImage = document.createElement('img');
  coinImage.src = 'https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52';
  coinImage.alt = 'Coin';
  coinImage.classList.add('coin-box-image');
  vehiclePrice.appendChild(coinImage);

  const addToCartButton = document.createElement('button');
  addToCartButton.classList.add('add-to-cart-button');
  addToCartButton.innerHTML = `<i class="fa-solid fa-cart-arrow-down"></i> ${t('buy')}`;

  addToCartButton.addEventListener('click', () => showPurchaseModal(vehicle));

  if (isItem === false) {
    const enlargeIcon = document.createElement('i');
    enlargeIcon.classList.add('fas', 'fa-circle-info', 'enlarge-icon');
    enlargeIcon.addEventListener('click', () => showModal(vehicle));
    vehicleDetails.appendChild(enlargeIcon);
  };

  vehicleDetails.appendChild(vehiclePrice);
  vehicleDetails.appendChild(addToCartButton);

  vehicleContainer.appendChild(img);
  vehicleContainer.appendChild(vehicleName);
  vehicleContainer.appendChild(tagsContainer);
  vehicleContainer.appendChild(vehicleDetails);

  return vehicleContainer;
}

const modal = document.getElementById('vehicle-modal');
const modal2 = document.getElementById('purchase-modal');
const closeModal = document.getElementsByClassName('close')[0];
const modalImage = document.getElementById('modal-image');

closeModal.onclick = function () {
  modal.style.display = "none";
  modalImage.style.transform = '';
}

window.onclick = function (event) {
  if (event.target === modal) {
    modal.style.display = "none";
    modalImage.style.transform = '';
  }

  if (event.target === modal2) {
    modal2.style.display = "none";
  }
};

function showPurchaseModal(dataa) {
  const purchaseModal = document.getElementById('purchase-modal');
  const purchaseModalImage = document.getElementById('purchase-modal-image');
  const purchaseModalName = document.getElementById('purchase-modal-name');
  const purchaseModalPrice = document.getElementById('purchase-modal-price');
  const quantityInput = document.getElementById('quantity');
  const purchaseButton = document.getElementById('purchase-button');

  purchaseModalImage.src = dataa.image;
  purchaseModalName.textContent = dataa.name;

  purchaseModalPrice.innerHTML = `
    <div class="price">${dataa.price.toLocaleString()}
      <img src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52" alt="Coin">
    </div>
  `;
  
  quantityInput.value = "";
  purchaseModal.style.display = "flex";

  purchaseButton.onclick = () => {
    if (isPurchasing) return;

    const quantity = parseInt(quantityInput.value, 10);

    if (isNaN(quantity) || quantity < 1) {
      showNotification(t('invalid_quantity'), 'error');
      return;
    }

    isPurchasing = true;
    setButtonLoading(purchaseButton, true, 'purchasing', 'fa-cart-arrow-down');

    fetch('https://r_store/purchase', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        data: dataa,
        quantity: quantity,
      }),
    })
    .then(response => response.json())
    .then(result => {
      if (result.status === 'success') {
        showNotification(t('purchase_successful'), 'success');

        fetchCoinsAmount();

        purchaseModal.style.display = "none";
      } else {
        showNotification(t('coins_missing'), 'error');

        purchaseModal.style.display = "none";
      }

      isPurchasing = false;
      setButtonLoading(purchaseButton, false, 'buy', 'fa-cart-arrow-down');
    })
    .catch((error) => {
      console.error('Error: ', error);
      showNotification(t('purchase_failed'), 'error');

      isPurchasing = false;
      setButtonLoading(purchaseButton, false, 'buy', 'fa-cart-arrow-down');
    });
  };
}

function showModal(vehicle) {
  const modalImage = document.getElementById('modal-image');
  const modalName = document.getElementById('modal-name');
  const modalPriceContainer = document.getElementById('modal-price');
  const modal = document.getElementById('vehicle-modal');

  modalImage.src = vehicle.image;
  modalName.textContent = vehicle.name;

  modalPriceContainer.innerHTML = `
    <div class="price">${vehicle.price.toLocaleString()}
      <img src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52" alt="Coin">
    </div>
  `;

  modal.style.display = "flex";

  const testDriveButton = document.getElementById('test-drive-button');
  const newTestDriveButton = testDriveButton.cloneNode(true);

  testDriveButton.parentNode.replaceChild(newTestDriveButton, testDriveButton);

  newTestDriveButton.addEventListener('click', function () {
    setButtonLoading(newTestDriveButton, true, 'starting_test_drive', 'fa-car');

    fetch('https://r_store/startTestDrive', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ vehicleData: vehicle })
    })
    .then(() => {
      closeStoreMenu();

      fetch('https://r_store/close', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      setButtonLoading(newTestDriveButton, false, 'testDrive', 'fa-car');
    })
    .catch((error) => {
      console.error('Test drive error:', error);
      setButtonLoading(newTestDriveButton, false, 'testDrive', 'fa-car');
    });
  });
}

document.querySelectorAll('.close').forEach((closeButton) => {
  closeButton.addEventListener('click', () => {
    document.querySelectorAll('.modal').forEach((modal) => {
      modal.style.display = "none";
    });
  });
});

document.addEventListener('keydown', function (event) {
  if (event.key === 'Escape') {
    if (!attemptCloseStore()) {
      return;
    }

    closeStoreMenu();

    fetch('https://r_store/close', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }
});

window.addEventListener('message', function (event) {
  if (event.data.action === 'open_store') {
    showLoadingOverlay();

    document.getElementById('store-container').style.display = 'block';

    document.getElementById('coinAmount').innerText = event.data.coins;

    setTimeout(function () {
      hideLoadingOverlay();
      showPage('page1');
    }, 1000);
  }
});
