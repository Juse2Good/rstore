let currentCategory = 'richest';

function initializeLeaderboard() {
  const categoryButtons = document.querySelectorAll('.category-btn');

  categoryButtons.forEach(button => {
    button.addEventListener('click', () => {
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');

      currentCategory = button.dataset.category;
      loadLeaderboard(currentCategory);
    });
  });

  loadLeaderboard(currentCategory);
}

function loadLeaderboard(category) {
  showLoadingOverlay();

  fetch('https://r_store/getleaderboard', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      category: category
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        displayLeaderboard(data.leaderboard);
      } else {
        showNotification(t('leaderboard_load_failed'), 'error');
      }
      hideLoadingOverlay();
    })
    .catch(error => {
      showNotification(t('leaderboard_load_failed'), 'error');
      console.error('Leaderboard error:', error);
      hideLoadingOverlay();
    });
}

function displayLeaderboard(data) {
  const listContainer = document.getElementById('leaderboard-list');
  listContainer.innerHTML = '';

  if (!data || data.length === 0) {
    listContainer.innerHTML = '<div class="no-data">' + t('no_leaderboard_data') + '</div>';
    return;
  }

  data.forEach((entry, index) => {
    const row = document.createElement('div');
    row.classList.add('leaderboard-row');

    if (index === 0) row.classList.add('top-1');
    if (index === 1) row.classList.add('top-2');
    if (index === 2) row.classList.add('top-3');

    const rankIcon = index < 3 ? getMedalIcon(index + 1) : '';

    row.innerHTML = `
      <span class="rank-column">${rankIcon} #${entry.rank}</span>
      <span class="name-column">${escapeHtml(entry.name || 'Unknown')}</span>
      <span class="value-column">${formatValue(entry.value, currentCategory)}</span>
    `;

    listContainer.appendChild(row);
  });
}

function getMedalIcon(rank) {
  const medals = {
    1: '<i class="fas fa-trophy" style="color: #FFD700;"></i>',
    2: '<i class="fas fa-medal" style="color: #C0C0C0;"></i>',
    3: '<i class="fas fa-medal" style="color: #CD7F32;"></i>'
  };
  return medals[rank] || '';
}

function formatValue(value, category) {
  if (category === 'most_games') {
    return value + ' ' + t('games');
  }
  return value.toLocaleString() + ' <img src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52" style="width: 16px; height: 16px; vertical-align: middle;">';
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

document.addEventListener('DOMContentLoaded', function() {
  const leaderboardPage = document.getElementById('leaderboardPage');
  if (leaderboardPage) {
    const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.target.id === 'leaderboardPage' && mutation.target.style.display !== 'none') {
          initializeLeaderboard();
        }
      });
    });

    observer.observe(leaderboardPage, {
      attributes: true,
      attributeFilter: ['style']
    });
  }
});
