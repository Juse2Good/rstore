function applyTheme(themeName) {
  if (!themes[themeName]) {
      console.error(`Theme "${themeName}" does not exist.`);
      return;
  }

  const theme = themes[themeName];
  const root = document.documentElement;

  Object.keys(theme).forEach(key => {
      root.style.setProperty(key, theme[key]);
  });

  config.theme = themeName;
}

function showPage(pageId) {
  if (isGameActive && typeof isGameActive === 'function' && isGameActive()) {
    showNotification(t('cannot_close_during_game'), 'error');
    return;
  }

  showLoadingOverlay();

  setTimeout(() => {
    clearSearchInput();
    searchItems();

    var pages = document.querySelectorAll('.page-content');

    pages.forEach(function (page) {
      page.style.display = 'none';
    });

    document.querySelectorAll('.page-buttons button').forEach(button => button.classList.remove('active'));
    document.querySelectorAll('.extra-button').forEach(button => button.classList.remove('active'));

    const casinoPages = ['page5', 'coinflipPage', 'minesPage', 'towerPage', 'casesPage', 'caseDetailsPage'];
    const isCasinoPage = casinoPages.includes(pageId);

    const buttonId = isCasinoPage ? 'btnPage5' : `btn${pageId.charAt(0).toUpperCase() + pageId.slice(1)}`;
    const activeButton = document.getElementById(buttonId);

    if (activeButton) {
      activeButton.classList.add('active');
    }

    document.getElementById(pageId).style.display = 'block';

    hideLoadingOverlay();
  }, 300);
}

function debounce(func, delay) {
  let timeout;
  return function (...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), delay);
  };
}

document.getElementById('searchInput').addEventListener('input',
  debounce(function () {
    searchItems();
  }, 50)
);

function searchItems() {
  var input = document.getElementById('searchInput').value.toUpperCase();
  foundAny = false;

  ['page1', 'page2', 'page3', 'page4'].forEach(pageId => {
    var container = document.getElementById(pageId);
    if (!container) return;

    var items = Array.from(container.querySelectorAll('.item-container, .vehicle-container'));

    items.forEach(function (item) {
      var nameElement = item.querySelector('.item-name') || item.querySelector('.vehicle-name');
      var priceElement = item.querySelector('.item-price') || item.querySelector('.price');
      var tagsContainer = item.querySelector('.tags-container');

      if (!nameElement || !priceElement || !tagsContainer) return;

      var name = nameElement.innerText.toUpperCase();

      var price = priceElement.innerText.replace(/[^0-9]/g, '').toUpperCase();

      var tags = Array.from(tagsContainer.querySelectorAll('.tag')).map(tag => tag.textContent.toUpperCase()).join(' ');

      if (name.indexOf(input) > -1 || price.indexOf(input) > -1 || tags.indexOf(input) > -1) {
        item.style.display = '';

        item.classList.add('fade-in');
        foundAny = true;
      } else {
        item.classList.remove('fade-in');
        item.classList.add('fade-out');

        setTimeout(function () {
          item.style.display = 'none';
        }, 300);
      }
    });
  });

  if (foundAny === false) {
    sleep(200).then(() => {
      showNotification(t('notFoundMessage'), 'error'); 
  });
  }
}

function clearSearchInput() {
  document.getElementById('searchInput').value = '';
}

function closeStoreMenu() {
  hideLoadingOverlay();
  
  document.getElementById('store-container').style.display = 'none';
  document.getElementById('vehicle-modal').style.display = 'none';
  document.getElementById('purchase-modal').style.display = 'none';
}

function showLoadingOverlay() {
  document.getElementById('loading-overlay2').style.display = 'flex';
}

function hideLoadingOverlay() {
  document.getElementById('loading-overlay2').style.display = 'none';
}

function showNotification(message, type) {
  const notification = document.getElementById('notification');
  const notificationIcon = document.getElementById('notification-icon');
  const notificationMessage = document.getElementById('notification-message');

  const icons = {
    success: '<i class="fas fa-check-circle"></i>',
    error: '<i class="fas fa-times-circle"></i>',
    warning: '<i class="fas fa-exclamation-triangle"></i>',
    info: '<i class="fas fa-info-circle"></i>',
  };

  notificationMessage.textContent = message;
  notificationIcon.innerHTML = icons[type] || '';

  notification.classList.remove('slide-in-top', 'slide-out-top', 'success', 'error', 'warning', 'info');
  notification.classList.add(type, 'slide-in-top');

  notification.style.display = 'flex';

  setTimeout(() => {
    notification.classList.remove('slide-in-top');
    notification.classList.add('slide-out-top');
  }, 2000);

  setTimeout(() => {
    notification.style.display = 'none';
    notification.classList.remove('slide-out-top');
  }, 2500);
}

function fetchCoinsAmount() {
  fetch('https://r_store/getcoins', {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        displayCoinsAmount(data.coins);
      } else {
        console.error('Failed to fetch coins amount:', data.message);
      }
    })
    .catch(error => {
      console.error('Error fetching coins amount:', error);
    });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function displayCoinsAmount(amount) {
  const coinsElement = document.getElementById('coinAmount');
  if (coinsElement) {
    coinsElement.innerHTML = `${amount}`;

    coinsElement.classList.remove('animate');
    void coinsElement.offsetWidth;
    coinsElement.classList.add('animate');
  }
}

function playSound(soundName, soundSet) {
  fetch('https://r_store/playsound', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      sound: soundName,
      set: soundSet || 'HUD_FRONTEND_DEFAULT_SOUNDSET'
    })
  }).catch(error => {
    console.error('Sound error:', error);
  });
}
