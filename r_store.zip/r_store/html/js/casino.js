const casesData = getCasesData();

const rarityProbabilities = {
  common: 50,
  rare: 35,
  epic: 12,
  legendary: 3,
};

function setButtonLoading(buttonElement, isLoading, textKey, icon) {
  if (isLoading) {
    buttonElement.disabled = true;
    buttonElement.classList.add('loading');
    buttonElement.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> <span data-translate="${textKey}">${t(textKey)}</span>`;
  } else {
    buttonElement.disabled = false;
    buttonElement.classList.remove('loading');
    buttonElement.innerHTML = `<i class="fa-solid ${icon}"></i> <span data-translate="${textKey}">${t(textKey)}</span>`;
  }
}

function applyCasinoTranslations() {
  document.querySelectorAll('[data-translate]').forEach(element => {
    const key = element.getAttribute('data-translate');
    element.textContent = t(key);
  });

  document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
    const key = element.getAttribute('data-translate-placeholder');
    element.placeholder = t(key);
  });
}

function setQuickBet(game, amount) {
  let inputElement;
  let maxAmount = 10000;

  if (game === 'coinflip') {
    inputElement = document.getElementById('betAmount');
  } else if (game === 'mines') {
    inputElement = document.getElementById('minesBetAmount');
  } else if (game === 'tower') {
    inputElement = document.getElementById('towerBetAmount');
  } else if (game === 'keno') {
    inputElement = document.getElementById('kenoBetAmount');
  } else if (game === 'dice') {
    inputElement = document.getElementById('diceBetAmount');
  }

  if (!inputElement) {
    console.error('Input element not found for game:', game);
    return;
  }

  if (amount === 'max') {
    const coinsElement = document.getElementById('coinAmount');
    if (!coinsElement) {
      console.error('Coin amount element not found');
      amount = 100;
    } else {
      const coinsText = coinsElement.textContent || coinsElement.innerText || '0';
      const cleanedText = coinsText.trim().replace(/[^0-9]/g, '');
      const currentCoins = parseInt(cleanedText, 10) || 0;

      console.log('Current coins:', currentCoins);

      if (currentCoins >= 100) {
        amount = Math.min(currentCoins, maxAmount);
      } else {
        amount = 100;
      }
    }
  }

  console.log('Setting bet to:', amount);
  inputElement.value = amount;

  if (game === 'coinflip') {
    const playButton = document.getElementById('playButton');
    const currentBetDisplay = document.getElementById('currentBet');
    if (playButton && currentBetDisplay) {
      if (amount >= 100) {
        playButton.disabled = false;
        currentBetDisplay.textContent = amount;
      } else {
        playButton.disabled = true;
        currentBetDisplay.textContent = '0';
      }
    }
  }

  playSound('CLICK', 'WEB_NAVIGATION_SOUNDS_PHONE');
}

function initializeCasesPage() {
  const casesContainer = document.getElementById('cases-container');
  if (!casesContainer) return;

  casesContainer.innerHTML = '';

  casesData.forEach(caseData => {
    const caseCard = document.createElement('div');
    caseCard.classList.add('case-card');

    const lockIcon = caseData.requiredRole ? '<div class="role-lock-icon"><i class="fa-solid fa-lock"></i></div>' : '';

    caseCard.innerHTML = `
      ${lockIcon}
      <img src="${caseData.image}" alt="${caseData.name}">
      <h3>${caseData.name}</h3>
      <p class="case-price">${caseData.price} <img src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52" alt="coins" style="width: 20px; height: 20px; vertical-align: middle;"></p>
    `;

    caseCard.addEventListener('click', () => showCaseDetails(caseData));
    casesContainer.appendChild(caseCard);
  });
}

function showCaseDetails(caseData) {
  document.getElementById('caseName').textContent = caseData.name;

  const casePriceElement = document.getElementById('casePrice');
  casePriceElement.innerHTML = `Hinta: ${caseData.price} <img src="https://scontent-hel3-1.xx.fbcdn.net/v/t39.30808-6/528746860_122138007980824197_4332956586740883519_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=mJOIFQMWHKoQ7kNvwHwW40f&_nc_oc=AdnGkoxOD5XfjBojyTeET28HA76gqE7zKlOdEmPCiKrH3Pw_8qB0e6fzhsNWNmwd4oA&_nc_zt=23&_nc_ht=scontent-hel3-1.xx&_nc_gid=Wq5rkXFqeAJHE5u9QaGspw&oh=00_AfhRoLE8jmddec47en_x5nYnIfb4JFvS8JA6fBj6A6hbHA&oe=69255E52" alt="coins" style="width: 24px; height: 24px; vertical-align: middle;">`;

  const caseItemsContainer = document.getElementById('caseItemsContainer');
  caseItemsContainer.innerHTML = '';

  caseData.contains.forEach(item => {
    const itemDiv = document.createElement('div');

    itemDiv.classList.add('case-item', item.rarity);
    itemDiv.innerHTML = `
      <img src="${item.image}" alt="${item.name}">
      <h4>${item.name}</h4>
    `;

    caseItemsContainer.appendChild(itemDiv);
  });

  const openCaseButton = document.getElementById('openCaseButton');
  openCaseButton.onclick = () => openCase(caseData);

  showPage('caseDetailsPage');
}

function getRandomItem(caseData) {
  const items = caseData.contains;
  const random = Math.random() * 100;

  let cumulativeProbability = 0;
  const rarities = ['legendary', 'epic', 'rare', 'common'];

  for (const rarity of rarities) {
    cumulativeProbability += rarityProbabilities[rarity];
    if (random <= cumulativeProbability) {
      const itemsOfRarity = items.filter(item => item.rarity === rarity);
      if (itemsOfRarity.length > 0) {
        return itemsOfRarity[Math.floor(Math.random() * itemsOfRarity.length)];
      }
    }
  }

  return items[Math.floor(Math.random() * items.length)];
}

function openCase(caseData) {
  const openCaseButton = document.getElementById('openCaseButton');
  setButtonLoading(openCaseButton, true, 'opening_case', 'fa-lock-open');

  const wonItem = getRandomItem(caseData);

  fetch('https://r_store/removecasecoins', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      casePrice: caseData.price,
      requiredRole: caseData.requiredRole || null,
      caseValue: caseData.value,
      cooldownHours: caseData.cooldownHours || 0
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        fetchCoinsAmount();
        startCaseOpening(caseData, wonItem);
      } else {
        showNotification(data.message || t('coins_missing'), 'error');
        setButtonLoading(openCaseButton, false, 'open_case', 'fa-lock-open');
      }
    })
    .catch(error => {
      showNotification(t('purchase_failed'), 'error');
      console.error('Open case error:', error);
      setButtonLoading(openCaseButton, false, 'open_case', 'fa-lock-open');
    });
}

function startCaseOpening(caseData, wonItem) {
  isCaseOpening = true;

  const overlay = document.getElementById('caseOpeningOverlay');
  const spinnerTrack = document.getElementById('caseOpeningItems');

  overlay.style.display = 'flex';
  spinnerTrack.innerHTML = '';
  spinnerTrack.style.transition = 'none';
  spinnerTrack.style.transform = 'translateX(0) translateY(-50%)';

  const totalItems = 100;
  const winnerPosition = 97;
  const animationItems = [];

  for (let i = 0; i < totalItems; i++) {
    animationItems.push(getRandomItem(caseData));
  }

  animationItems[winnerPosition] = wonItem;

  animationItems.forEach(item => {
    const itemDiv = document.createElement('div');
    itemDiv.classList.add('spinner-item', item.rarity);
    itemDiv.innerHTML = `<img src="${item.image}" alt="${item.name}">`;
    spinnerTrack.appendChild(itemDiv);
  });

  const itemWidth = 150;
  const itemGap = 20;
  const itemTotalWidth = itemWidth + itemGap;

  playSound('PICK_UP_WEAPON', 'HUD_FRONTEND_CUSTOM_SOUNDSET');

  setTimeout(() => {
    const spinnerContainer = spinnerTrack.parentElement;
    const containerWidth = spinnerContainer.offsetWidth;
    const markerPosition = containerWidth / 2;
    const winningItemCenter = (winnerPosition * itemTotalWidth) + (itemWidth / 2);
    const targetPosition = markerPosition - winningItemCenter;

    spinnerTrack.style.transition = 'transform 5s cubic-bezier(0.15, 0.7, 0.1, 1)';
    spinnerTrack.style.transform = `translateX(${targetPosition}px) translateY(-50%)`;
  }, 100);

  setTimeout(() => {
    playSound('RACE_PLACED', 'HUD_AWARDS');

    overlay.style.display = 'none';
    spinnerTrack.style.transition = 'none';
    spinnerTrack.style.transform = 'translateX(0) translateY(-50%)';

    const openCaseButton = document.getElementById('openCaseButton');
    setButtonLoading(openCaseButton, false, 'open_case', 'fa-lock-open');

    fetch('https://r_store/givecasereward', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        wonItem: wonItem
      })
    })
      .then(response => response.json())
      .then(result => {
        if (result.status === 'success') {
          showNotification(`${t('you_won')}: ${wonItem.name}!`, 'success');
          fetchCoinsAmount();
        } else {
          showNotification(t('purchase_failed'), 'error');
        }
        isCaseOpening = false;
      })
      .catch(error => {
        showNotification(t('purchase_failed'), 'error');
        console.error('Give reward error:', error);
        isCaseOpening = false;
      });
  }, 5100);
}

let isPlaying = false;
let isCaseOpening = false;
let isMinesActive = false;

function isGameActive() {
  return isPlaying || isCaseOpening || isMinesActive || isTowerActive || isKenoActive || isDiceActive;
}

function attemptCloseStore() {
  if (isGameActive()) {
    showNotification(t('cannot_close_during_game'), 'error');
    return false;
  }
  return true;
}

document.getElementById('betAmount').addEventListener('input', function () {
  const betAmountInput = document.getElementById('betAmount');
  let betAmount = parseInt(betAmountInput.value);

  if (betAmount < 100) {
    betAmount = 100;
    betAmountInput.value = betAmount;
  }

  if (betAmount > 10000) {
    betAmount = 10000;
    betAmountInput.value = betAmount;
  }

  const playButton = document.getElementById('playButton');
  const currentBetDisplay = document.getElementById('currentBet');

  if (betAmount >= 100) {
    playButton.disabled = false;
    currentBetDisplay.textContent = betAmount;
  } else {
    playButton.disabled = true;
    currentBetDisplay.textContent = '0';
  }
});

function playCoinflip() {
  if (isPlaying) return;

  const betAmountInput = document.getElementById('betAmount');
  const betAmount = parseInt(betAmountInput.value);
  const playButton = document.getElementById('playButton');

  if (!betAmount || betAmount < 100) {
    showNotification(t('min_bet'), 'error');
    return;
  }

  setButtonLoading(playButton, true, 'placing_bet', 'fa-play');

  fetch('https://r_store/removecoinflipbet', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      betAmount: betAmount
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        fetchCoinsAmount();
        setButtonLoading(playButton, false, 'play', 'fa-play');
        startCoinflip(betAmount);
      } else {
        showNotification(data.message || t('coins_missing'), 'error');
        setButtonLoading(playButton, false, 'play', 'fa-play');
      }
    })
    .catch(error => {
      showNotification(t('check_coins_failed'), 'error');
      console.error('Coinflip error:', error);
      setButtonLoading(playButton, false, 'play', 'fa-play');
    });
}

function startCoinflip(betAmount) {
  isPlaying = true;
  const coin = document.getElementById('coin');
  const playButton = document.getElementById('playButton');

  setButtonLoading(playButton, true, 'flipping', 'fa-play');
  coin.classList.remove('flipping');
  void coin.offsetWidth;

  const result = Math.random() < 0.4 ? 'player' : 'bot';

  playSound('PICK_UP_WEAPON', 'HUD_FRONTEND_CUSTOM_SOUNDSET');

  coin.classList.add('flipping');

  setTimeout(() => {
    coin.src = result === 'player' ? 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/team2.png' : 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/teambot.png';
  }, 1500);

  setTimeout(() => {
    coin.classList.remove('flipping');

    if (result === 'player') {
      playSound('CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET');
      fetch('https://r_store/givecoinflipwinnings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          betAmount: betAmount
        })
      })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            showNotification(`${t('you_won')}! +${betAmount} coins`, 'success');
            fetchCoinsAmount();
          } else {
            showNotification(t('purchase_failed'), 'error');
          }
        })
        .catch(error => {
          showNotification(t('purchase_failed'), 'error');
          console.error('Give winnings error:', error);
        });
    } else {
      playSound('CHECKPOINT_MISSED', 'HUD_MINI_GAME_SOUNDSET');
      showNotification(t('bot_won'), 'info');
    }

    isPlaying = false;
    setButtonLoading(playButton, false, 'play', 'fa-play');
  }, 3500);
}

let minesGameState = {
  active: false,
  betAmount: 0,
  mineCount: 0,
  minePositions: [],
  revealedTiles: [],
  multiplier: 1.0,
  hitMine: false
};

function initializeMinesGrid() {
  const grid = document.getElementById('minesGrid');
  grid.innerHTML = '';

  for (let i = 0; i < 25; i++) {
    const tile = document.createElement('div');
    tile.classList.add('mine-tile');
    tile.dataset.index = i;
    tile.addEventListener('click', () => clickTile(i));
    grid.appendChild(tile);
  }
}

function generateMinePositions(mineCount) {
  const positions = [];
  while (positions.length < mineCount) {
    const pos = Math.floor(Math.random() * 25);
    if (!positions.includes(pos)) {
      positions.push(pos);
    }
  }
  return positions;
}

function calculateMultiplier(mineCount, revealedCount) {
  const totalTiles = 25;
  const safeTiles = totalTiles - mineCount;

  if (revealedCount === 0) return 1.0;

  const powerFactor = 0.55 - (mineCount / 100);

  const houseEdge = 0.80 + (mineCount / 200);

  let multiplier = 1.0;
  for (let i = 0; i < revealedCount; i++) {
    const remainingSafe = safeTiles - i;
    const remainingTotal = totalTiles - i;
    const riskFactor = (remainingTotal / remainingSafe);

    multiplier *= Math.pow(riskFactor, powerFactor);
  }

  return multiplier * houseEdge;
}

function handleMinesAction() {
  if (minesGameState.active) {
    cashoutMines();
  } else {
    startMinesGame();
  }
}

function startMinesGame() {
  const betAmountInput = document.getElementById('minesBetAmount');
  const mineCountInput = document.getElementById('minesCount');
  const actionButton = document.getElementById('minesActionButton');

  const betAmount = parseInt(betAmountInput.value);
  const mineCount = parseInt(mineCountInput.value);

  if (!betAmount || betAmount < 100 || betAmount > 10000) {
    showNotification(t('invalid_bet_amount'), 'error');
    return;
  }

  if (!mineCount || mineCount < 3 || mineCount > 24) {
    showNotification(t('invalid_mine_count'), 'error');
    return;
  }

  setButtonLoading(actionButton, true, 'starting_game', 'fa-play');

  fetch('https://r_store/startmines', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      betAmount: betAmount,
      mineCount: mineCount
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        fetchCoinsAmount();

        isMinesActive = true;
        minesGameState.active = true;
        minesGameState.betAmount = betAmount;
        minesGameState.mineCount = mineCount;
        minesGameState.minePositions = generateMinePositions(mineCount);
        minesGameState.revealedTiles = [];
        minesGameState.multiplier = 1.0;

        initializeMinesGrid();
        updateMinesStats();

        betAmountInput.disabled = true;
        mineCountInput.disabled = true;

        actionButton.disabled = true;
        actionButton.classList.add('cashout');
        actionButton.classList.remove('loading');
        actionButton.innerHTML = '<i class="fa-solid fa-sack-dollar"></i> <span data-translate="cash_out">' + t('cash_out') + '</span>';

        const tiles = document.querySelectorAll('.mine-tile');
        tiles.forEach(tile => tile.classList.remove('disabled'));
      } else {
        showNotification(data.message || t('coins_missing'), 'error');
        setButtonLoading(actionButton, false, 'start_game', 'fa-play');
      }
    })
    .catch(error => {
      showNotification(t('purchase_failed'), 'error');
      console.error('Start mines error:', error);
      setButtonLoading(actionButton, false, 'start_game', 'fa-play');
    });
}

function clickTile(index) {
  if (!minesGameState.active) {
    showNotification(t('must_start_game'), 'error');
    return;
  }

  if (minesGameState.revealedTiles.includes(index)) {
    return;
  }

  const tile = document.querySelector(`.mine-tile[data-index="${index}"]`);
  minesGameState.revealedTiles.push(index);

  playSound('CLICK', 'WEB_NAVIGATION_SOUNDS_PHONE');

  if (minesGameState.minePositions.includes(index)) {
    playSound('LOSER', 'HUD_AWARDS');
    tile.classList.add('revealed', 'mine');
    tile.innerHTML = '<i class="fa-solid fa-bomb"></i>';

    minesGameState.active = false;
    minesGameState.hitMine = true;
    isMinesActive = false;

    const actionButton = document.getElementById('minesActionButton');
    actionButton.disabled = true;

    const tiles = document.querySelectorAll('.mine-tile');
    tiles.forEach(t => t.classList.add('disabled'));

    setTimeout(() => {
      showNotification(t('you_hit_mine'), 'error');
      resetMinesGame();
    }, 1000);
  } else {
    playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');
    tile.classList.add('revealed', 'safe');
    tile.innerHTML = '<i class="fa-solid fa-gem"></i>';

    minesGameState.multiplier = calculateMultiplier(minesGameState.mineCount, minesGameState.revealedTiles.length);
    updateMinesStats();

    document.getElementById('minesActionButton').disabled = false;

    const autoCashoutInput = document.getElementById('autoCashoutTarget');
    const autoCashoutTarget = parseFloat(autoCashoutInput.value);

    if (autoCashoutInput.value && !isNaN(autoCashoutTarget) && autoCashoutTarget >= 1.5 && minesGameState.multiplier >= autoCashoutTarget) {
      showNotification(`${t('auto_cashout_triggered')}: ${autoCashoutTarget}x`, 'success');
      setTimeout(() => {
        cashoutMines();
      }, 500);
      return;
    }

    if (minesGameState.revealedTiles.length === 25 - minesGameState.mineCount) {
      setTimeout(() => {
        cashoutMines();
      }, 500);
    }
  }
}

function updateMinesStats() {
  const multiplierElement = document.getElementById('minesMultiplier');
  const profitElement = document.getElementById('minesProfit');
  const revealedElement = document.getElementById('minesRevealed');

  multiplierElement.textContent = minesGameState.multiplier.toFixed(2) + 'x';

  const profit = Math.floor(minesGameState.betAmount * minesGameState.multiplier) - minesGameState.betAmount;
  profitElement.textContent = profit;

  const totalSafe = 25 - minesGameState.mineCount;
  revealedElement.textContent = `${minesGameState.revealedTiles.length}/${totalSafe}`;
}

function cashoutMines() {
  if (!minesGameState.active || minesGameState.hitMine) {
    showNotification(t('must_start_game'), 'error');
    return;
  }

  if (minesGameState.revealedTiles.length === 0) {
    showNotification(t('must_start_game'), 'error');
    return;
  }

  const actionButton = document.getElementById('minesActionButton');
  setButtonLoading(actionButton, true, 'cashing_out', 'fa-sack-dollar');

  const tiles = document.querySelectorAll('.mine-tile');
  tiles.forEach(t => t.classList.add('disabled'));

  playSound('CASH_REGISTER', 'HUD_MINI_GAME_SOUNDSET');

  fetch('https://r_store/cashoutmines', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      betAmount: minesGameState.betAmount,
      multiplier: minesGameState.multiplier,
      revealedCount: minesGameState.revealedTiles.length
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        fetchCoinsAmount();
        showNotification(`${t('cashed_out')}: +${data.winnings} coins!`, 'success');
        resetMinesGame();
      } else {
        showNotification(data.message || t('purchase_failed'), 'error');
        resetMinesGame();
      }
    })
    .catch(error => {
      showNotification(t('purchase_failed'), 'error');
      console.error('Cashout mines error:', error);
      resetMinesGame();
    });
}

function resetMinesGame() {
  isMinesActive = false;
  minesGameState.active = false;
  minesGameState.betAmount = 0;
  minesGameState.mineCount = 0;
  minesGameState.minePositions = [];
  minesGameState.revealedTiles = [];
  minesGameState.multiplier = 1.0;
  minesGameState.hitMine = false;

  const actionButton = document.getElementById('minesActionButton');
  actionButton.disabled = false;
  actionButton.classList.remove('cashout');
  actionButton.innerHTML = '<i class="fa-solid fa-play"></i> <span data-translate="start_game">' + t('start_game') + '</span>';

  document.getElementById('minesBetAmount').disabled = false;
  document.getElementById('minesCount').disabled = false;

  document.getElementById('minesMultiplier').textContent = '1.00x';
  document.getElementById('minesProfit').textContent = '0';
  document.getElementById('minesRevealed').textContent = '0/25';

  initializeMinesGrid();
}

let isTowerActive = false;
let towerGameState = {
  active: false,
  betAmount: 0,
  difficulty: 'easy',
  currentLevel: 0,
  maxLevels: 8,
  tilesPerLevel: 3,
  eggPositions: [],
  multiplier: 1.0,
  hitEgg: false
};

function initializeTowerGrid() {
  const towerGrid = document.getElementById('towerGrid');
  if (!towerGrid) return;

  towerGrid.innerHTML = '';

  for (let level = 0; level < towerGameState.maxLevels; level++) {
    const row = document.createElement('div');
    row.className = 'tower-row';
    row.dataset.level = level;

    for (let i = 0; i < towerGameState.tilesPerLevel; i++) {
      const tile = document.createElement('div');
      tile.className = 'tower-tile disabled';
      tile.dataset.level = level;
      tile.dataset.index = i;
      tile.onclick = () => clickTowerTile(level, i);
      row.appendChild(tile);
    }

    towerGrid.appendChild(row);
  }
}

function handleTowerAction() {
  if (!towerGameState.active) {
    startTowerGame();
  } else {
    cashoutTower();
  }
}

function startTowerGame() {
  const betAmount = parseInt(document.getElementById('towerBetAmount').value);
  const difficulty = document.getElementById('towerDifficulty').value;

  if (isNaN(betAmount) || betAmount < 100) {
    showNotification(t('min_bet'), 'error');
    return;
  }

  const actionButton = document.getElementById('towerActionButton');
  setButtonLoading(actionButton, true, 'starting_game', 'fa-play');

  playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');

  fetch('https://r_store/starttowergame', {
    method: 'POST',
    body: JSON.stringify({
      betAmount: betAmount,
      difficulty: difficulty
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        towerGameState.active = true;
        towerGameState.betAmount = betAmount;
        towerGameState.difficulty = difficulty;
        towerGameState.currentLevel = 0;
        towerGameState.multiplier = 1.0;
        towerGameState.hitEgg = false;
        towerGameState.eggPositions = data.eggPositions;

        isTowerActive = true;
        fetchCoinsAmount();

        document.getElementById('towerBetAmount').disabled = true;
        document.getElementById('towerDifficulty').disabled = true;

        setButtonLoading(actionButton, false, 'cash_out', 'fa-hand-holding-dollar');
        actionButton.classList.add('cashout');

        enableTowerLevel(0);
        updateTowerDisplay();
      } else {
        showNotification(data.message || t('not_enough_coins'), 'error');
        setButtonLoading(actionButton, false, 'start_game', 'fa-play');
      }
    })
    .catch(error => {
      showNotification(t('purchase_failed'), 'error');
      console.error('Start tower game error:', error);
      setButtonLoading(actionButton, false, 'start_game', 'fa-play');
    });
}

function enableTowerLevel(level) {
  const allTiles = document.querySelectorAll('.tower-tile');

  allTiles.forEach(tile => {
    const tileLevel = parseInt(tile.dataset.level);
    if (tileLevel === level) {
      tile.classList.remove('disabled');
      tile.classList.add('current-level');
    } else if (tileLevel > level) {
      tile.classList.add('disabled');
      tile.classList.remove('current-level');
    }
  });
}

function clickTowerTile(level, index) {
  if (!towerGameState.active || towerGameState.hitEgg) {
    return;
  }

  if (level !== towerGameState.currentLevel) {
    return;
  }

  const tile = document.querySelector(`.tower-tile[data-level="${level}"][data-index="${index}"]`);
  if (tile.classList.contains('revealed') || tile.classList.contains('disabled')) {
    return;
  }

  playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');

  const levelEggs = towerGameState.eggPositions[level];
  const isEgg = levelEggs.includes(index);

  tile.classList.add('revealed');
  tile.classList.remove('current-level');

  if (isEgg) {
    tile.classList.add('egg');
    tile.innerHTML = '🥚';

    towerGameState.active = false;
    towerGameState.hitEgg = true;
    isTowerActive = false;

    const actionButton = document.getElementById('towerActionButton');
    actionButton.disabled = true;

    playSound('LOSER', 'HUD_AWARDS');

    const allTiles = document.querySelectorAll('.tower-tile');
    allTiles.forEach(t => {
      t.classList.add('disabled');
    });

    showNotification(`${t('tower_failed')} ${t('hit_dragon_egg')}`, 'error');

    setTimeout(() => {
      resetTowerGame();
    }, 2000);
  } else {
    tile.classList.add('safe');
    tile.innerHTML = '✓';

    playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');

    const currentLevelTiles = document.querySelectorAll(`.tower-tile[data-level="${level}"]`);
    currentLevelTiles.forEach(t => {
      t.classList.add('disabled');
      t.classList.remove('current-level');
    });

    towerGameState.currentLevel++;
    towerGameState.multiplier = calculateTowerMultiplier(towerGameState.currentLevel, towerGameState.difficulty);
    updateTowerDisplay();

    if (towerGameState.currentLevel >= towerGameState.maxLevels) {
      playSound('CASH_REGISTER', 'HUD_SHOP_SOUNDSET');
      showNotification(`${t('tower_complete')}!`, 'success');
      cashoutTower();
    } else {
      enableTowerLevel(towerGameState.currentLevel);
    }
  }
}

function calculateTowerMultiplier(level, difficulty) {
  if (level === 0) return 1.0;

  let baseMultiplier = 1.0;

  const multipliers = {
    easy: 1.12,
    medium: 1.20,
    hard: 1.30
  };

  const levelMultiplier = multipliers[difficulty] || 1.12;

  for (let i = 0; i < level; i++) {
    baseMultiplier *= levelMultiplier;
  }

  return Math.round(baseMultiplier * 100) / 100;
}

function updateTowerDisplay() {
  document.getElementById('towerMultiplier').textContent = towerGameState.multiplier.toFixed(2) + 'x';

  const profit = Math.floor(towerGameState.betAmount * towerGameState.multiplier - towerGameState.betAmount);
  document.getElementById('towerProfit').textContent = profit;

  document.getElementById('towerLevel').textContent = `${towerGameState.currentLevel}/${towerGameState.maxLevels}`;
}

function cashoutTower() {
  if (!towerGameState.active || towerGameState.hitEgg) {
    showNotification(t('must_start_game'), 'error');
    return;
  }

  if (towerGameState.currentLevel === 0) {
    showNotification(t('must_start_game'), 'error');
    return;
  }

  const actionButton = document.getElementById('towerActionButton');
  setButtonLoading(actionButton, true, 'cashing_out', 'fa-hand-holding-dollar');

  playSound('CASH_REGISTER', 'HUD_SHOP_SOUNDSET');

  fetch('https://r_store/cashouttower', {
    method: 'POST',
    body: JSON.stringify({
      betAmount: towerGameState.betAmount,
      multiplier: towerGameState.multiplier
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        fetchCoinsAmount();
        showNotification(`${t('cashed_out')}: +${data.winnings} coins!`, 'success');
        resetTowerGame();
      } else {
        showNotification(data.message || t('purchase_failed'), 'error');
        resetTowerGame();
      }
    })
    .catch(error => {
      showNotification(t('purchase_failed'), 'error');
      console.error('Cashout tower error:', error);
      resetTowerGame();
    });
}

function resetTowerGame() {
  isTowerActive = false;
  towerGameState.active = false;
  towerGameState.betAmount = 0;
  towerGameState.currentLevel = 0;
  towerGameState.multiplier = 1.0;
  towerGameState.eggPositions = [];
  towerGameState.hitEgg = false;

  const actionButton = document.getElementById('towerActionButton');
  actionButton.disabled = false;
  actionButton.classList.remove('cashout');
  actionButton.innerHTML = '<i class="fa-solid fa-play"></i> <span data-translate="start_game">' + t('start_game') + '</span>';

  document.getElementById('towerBetAmount').disabled = false;
  document.getElementById('towerDifficulty').disabled = false;

  document.getElementById('towerMultiplier').textContent = '1.00x';
  document.getElementById('towerProfit').textContent = '0';
  document.getElementById('towerLevel').textContent = '0/8';

  initializeTowerGrid();
}

/* Keno Game */
let isKenoActive = false;
let kenoGameState = {
  selectedNumbers: [],
  drawnNumbers: [],
  hits: 0,
  payout: 0,
  isPlaying: false
};

function initializeKenoGrid() {
  const grid = document.getElementById('kenoGrid');
  if (!grid) return;

  grid.innerHTML = '';

  for (let i = 1; i <= 80; i++) {
    const number = document.createElement('div');
    number.classList.add('keno-number');
    number.textContent = i;
    number.dataset.number = i;
    number.addEventListener('click', () => toggleKenoNumber(i));
    grid.appendChild(number);
  }
}

function toggleKenoNumber(number) {
  if (kenoGameState.isPlaying) return;

  const numberElement = document.querySelector(`.keno-number[data-number="${number}"]`);
  const index = kenoGameState.selectedNumbers.indexOf(number);

  if (index > -1) {
    kenoGameState.selectedNumbers.splice(index, 1);
    numberElement.classList.remove('selected');
  } else {
    if (kenoGameState.selectedNumbers.length >= 10) {
      showNotification(t('keno_already_selected'), 'error');
      return;
    }
    kenoGameState.selectedNumbers.push(number);
    numberElement.classList.add('selected');
  }

  playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');
  updateKenoStats();
}

function clearKenoSelection() {
  if (kenoGameState.isPlaying) return;

  kenoGameState.selectedNumbers = [];
  kenoGameState.drawnNumbers = [];
  kenoGameState.hits = 0;
  kenoGameState.payout = 0;

  const allNumbers = document.querySelectorAll('.keno-number');
  allNumbers.forEach(num => {
    num.classList.remove('selected', 'drawn', 'hit', 'miss', 'disabled');
  });

  updateKenoStats();
  playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');
  showNotification(t('keno_selection_cleared'), 'info');
}

function updateKenoStats() {
  document.getElementById('kenoSelectedCount').textContent = `${kenoGameState.selectedNumbers.length}/10`;
  document.getElementById('kenoHits').textContent = kenoGameState.hits;
  document.getElementById('kenoPayout').textContent = `${kenoGameState.payout}x`;
}

function playKeno() {
  if (kenoGameState.isPlaying) return;

  if (kenoGameState.selectedNumbers.length !== 10) {
    showNotification(t('keno_select_numbers'), 'error');
    return;
  }

  const betAmountInput = document.getElementById('kenoBetAmount');
  const betAmount = parseInt(betAmountInput.value);

  if (!betAmount || betAmount < 100 || betAmount > 10000) {
    showNotification(t('invalid_bet_amount'), 'error');
    return;
  }

  const playButton = document.getElementById('kenoActionButton');
  const clearButton = document.getElementById('kenoClearButton');

  setButtonLoading(playButton, true, 'keno_drawing', 'fa-play');
  clearButton.disabled = true;

  kenoGameState.isPlaying = true;
  isKenoActive = true;

  const allNumbers = document.querySelectorAll('.keno-number');
  allNumbers.forEach(num => num.classList.add('disabled'));

  fetch('https://r_store/playkeno', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      betAmount: betAmount,
      selectedNumbers: kenoGameState.selectedNumbers
    })
  })
  .then(response => response.json())
  .then(data => {
    if (data.status === 'success') {
      fetchCoinsAmount();
      kenoGameState.drawnNumbers = data.drawnNumbers;
      kenoGameState.hits = data.hits;

      const payoutTable = {
        0: 0, 1: 0, 2: 0, 3: 0, 4: 1.5,
        5: 2.0, 6: 5.0, 7: 10.0, 8: 20.0, 9: 30.0, 10: 40.0
      };

      kenoGameState.payout = payoutTable[data.hits] || 0;

      animateKenoDraw(data.drawnNumbers, data.hits, data.winnings);
    } else {
      showNotification(data.message || t('coins_missing'), 'error');
      resetKenoGame();
    }
  })
  .catch(error => {
    showNotification(t('purchase_failed'), 'error');
    console.error('Keno error:', error);
    resetKenoGame();
  });
}

function animateKenoDraw(drawnNumbers, hits, winnings) {
  let drawIndex = 0;
  const drawInterval = 100; 

  playSound('PICK_UP_WEAPON', 'HUD_FRONTEND_CUSTOM_SOUNDSET');

  const interval = setInterval(() => {
    if (drawIndex >= drawnNumbers.length) {
      clearInterval(interval);
      finishKenoDraw(hits, winnings);
      return;
    }

    const drawnNumber = drawnNumbers[drawIndex];
    const numberElement = document.querySelector(`.keno-number[data-number="${drawnNumber}"]`);

    if (numberElement) {
      numberElement.classList.add('drawn');

      if (kenoGameState.selectedNumbers.includes(drawnNumber)) {
        setTimeout(() => {
          numberElement.classList.add('hit');
          playSound('CLICK_BACK', 'WEB_NAVIGATION_SOUNDS_PHONE');
        }, 200);
      }
    }

    drawIndex++;
  }, drawInterval);
}

function finishKenoDraw(hits, winnings) {
  kenoGameState.selectedNumbers.forEach(num => {
    if (!kenoGameState.drawnNumbers.includes(num)) {
      const numberElement = document.querySelector(`.keno-number[data-number="${num}"]`);
      if (numberElement) {
        numberElement.classList.add('miss');
      }
    }
  });

  updateKenoStats();

  setTimeout(() => {
    if (hits >= 4) {
      playSound('RACE_PLACED', 'HUD_AWARDS');
      showNotification(`${t('you_won')}: ${winnings} coins! (${hits} ${t('keno_hits')})`, 'success');
    } else {
      playSound('CHECKPOINT_MISSED', 'HUD_MINI_GAME_SOUNDSET');
      showNotification(`${hits} ${t('keno_hits')} - ${t('game_over')}`, 'info');
    }

    resetKenoGame();
  }, 1000);
}

function resetKenoGame() {
  isKenoActive = false;
  kenoGameState.isPlaying = false;

  const playButton = document.getElementById('kenoActionButton');
  const clearButton = document.getElementById('kenoClearButton');

  setButtonLoading(playButton, false, 'play', 'fa-play');
  clearButton.disabled = false;

  const allNumbers = document.querySelectorAll('.keno-number');
  allNumbers.forEach(num => {
    num.classList.remove('disabled', 'drawn', 'hit', 'miss');
  });
}

let isDiceActive = false;

function calculateDiceMultiplier(predictionType, target) {
  const multipliers = {
    under: {
      3: 4.00,
      4: 3.00,
      5: 2.50,
      6: 2.00,
      7: 1.80
    },
    over: {
      7: 1.80,
      8: 2.00,
      9: 2.50,
      10: 3.00,
      11: 4.00
    }
  };

  return multipliers[predictionType][target] || 0;
}

function updateDicePrediction() {
  const predictionType = document.getElementById('dicePredictionType').value;
  const target = parseInt(document.getElementById('diceTarget').value);

  const predictionText = predictionType === 'under' ? `${t('dice_under')} ${target}` : `${t('dice_over')} ${target}`;
  document.getElementById('dicePrediction').textContent = predictionText;

  const multiplier = calculateDiceMultiplier(predictionType, target);
  document.getElementById('diceMultiplier').textContent = multiplier.toFixed(2) + 'x';
}

function playDice() {
  if (isDiceActive) return;

  const betAmountInput = document.getElementById('diceBetAmount');
  const betAmount = parseInt(betAmountInput.value);
  const predictionType = document.getElementById('dicePredictionType').value;
  const target = parseInt(document.getElementById('diceTarget').value);

  if (!betAmount || betAmount < 100 || betAmount > 10000) {
    showNotification(t('invalid_bet_amount'), 'error');
    return;
  }

  if ((predictionType === 'under' && (target < 3 || target > 7)) ||
      (predictionType === 'over' && (target < 7 || target > 11))) {
    showNotification(t('invalid_dice_target'), 'error');
    return;
  }

  const actionButton = document.getElementById('diceActionButton');
  setButtonLoading(actionButton, true, 'dice_rolling', 'fa-dice');

  isDiceActive = true;

  const dice1 = document.getElementById('dice1');
  const dice2 = document.getElementById('dice2');
  dice1.classList.add('rolling');
  dice2.classList.add('rolling');

  playSound('PICK_UP_WEAPON', 'HUD_FRONTEND_CUSTOM_SOUNDSET');

  fetch('https://r_store/playdice', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      betAmount: betAmount,
      predictionType: predictionType,
      target: target
    })
  })
  .then(response => response.json())
  .then(data => {
    if (data.status === 'success') {
      fetchCoinsAmount();

      setTimeout(() => {
        dice1.classList.remove('rolling');
        dice2.classList.remove('rolling');

        const dice1Face = dice1.querySelector('.dice-face');
        const dice2Face = dice2.querySelector('.dice-face');
        dice1Face.textContent = data.dice1;
        dice2Face.textContent = data.dice2;

        const sum = data.dice1 + data.dice2;
        document.getElementById('diceSum').textContent = `Yhteensä: ${sum}`;
        document.getElementById('diceLastResult').textContent = sum;

        setTimeout(() => {
          if (data.won) {
            playSound('RACE_PLACED', 'HUD_AWARDS');
            showNotification(`${t('dice_win')} +${data.winnings} coins!`, 'success');
          } else {
            playSound('CHECKPOINT_MISSED', 'HUD_MINI_GAME_SOUNDSET');
            showNotification(t('dice_lose'), 'info');
          }

          isDiceActive = false;
          setButtonLoading(actionButton, false, 'roll_dice', 'fa-dice');
        }, 500);
      }, 1000);
    } else {
      showNotification(data.message || t('coins_missing'), 'error');
      dice1.classList.remove('rolling');
      dice2.classList.remove('rolling');
      isDiceActive = false;
      setButtonLoading(actionButton, false, 'roll_dice', 'fa-dice');
    }
  })
  .catch(error => {
    showNotification(t('purchase_failed'), 'error');
    console.error('Dice error:', error);
    dice1.classList.remove('rolling');
    dice2.classList.remove('rolling');
    isDiceActive = false;
    setButtonLoading(actionButton, false, 'roll_dice', 'fa-dice');
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initializeCasesPage();
  applyCasinoTranslations();
  initializeMinesGrid();
  initializeTowerGrid();
  initializeKenoGrid();
  updateDicePrediction();
});
