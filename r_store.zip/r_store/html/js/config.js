function getVehiclesData() {
    return [
        { name: 'Seraph XS', value: 'm5e60', type: 'vehicle', price: 8500, image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/wisedev-trailcat-littlemonster.png', onSale: false, isNew: false },
        { name: 'Cyber', value: 'cybertruckv', type: 'vehicle', price: 40000, image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/cybertruckv.png', onSale: false, isNew: false },
        { name: 'Helikopteri', value: 'Buzzard2', type: 'vehicle', price: 50000, image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/buzzard2.png', onSale: false, isNew: false },
    ];
}

function getItemsDataPage2() {
    return [
        {
            name: '10,000€',
            type: 'money',
            price: 1000,
            value: 10000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/money.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: '25,000€',
            type: 'money',
            price: 2500,
            value: 25000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/money.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: '50,000€',
            type: 'money',
            price: 4500,
            value: 50000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/money.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: '100,000€',
            type: 'money',
            price: 8000,
            value: 100000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/money.png',
            IsSale: false,
            IsNew: false,
        },
    ];
}

function getItemsDataPage3() {
    return [
        {
            name: '9mm Panos',
            type: 'item',
            value: 'ammo-9',
            price: 10,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/ammo-9.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Kiväärin Panos',
            type: 'item',
            value: 'ammo-rifle',
            price: 30,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/ammo-rifle.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Luotiliivi',
            type: 'item',
            value: 'armour',
            price: 500,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/armour.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Avain A',
            type: 'item',
            value: 'keya',
            price: 1000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/keya.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Avain B',
            type: 'item',
            value: 'keyb',
            price: 1000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/keyb.png',
            IsSale: false,
            IsNew: false,
        }
    ];
}

function getItemsDataPage4() {
    return [
        {
            name: 'Pistol MK2',
            type: 'weapon',
            value: 'weapon_pistol_mk2',
            price: 2500,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_pistol_mk2.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Vintage Pistol',
            type: 'weapon',
            value: 'weapon_vintagepistol',
            price: 2500,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_vintagepistol.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Pistol SNS MK2',
            type: 'weapon',
            value: 'weapon_snspistol_mk2',
            price: 2500,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_snspistol_mk2.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'AK-47',
            type: 'weapon',
            value: 'weapon_assaultrifle',
            price: 6000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_assaultrifle.png',
            IsSale: false,
            IsNew: false,
        },
        {
            name: 'Micro SMG',
            type: 'weapon',
            value: 'weapon_microsmg',
            price: 5000,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_microsmg.png',
            IsSale: false,
            IsNew: false,
        },
    ];
}

function getCasesData() {
    return [
        {
            name: 'Boosters',
            value: 'vip',
            type: 'case',
            price: 0,
            image: 'https://r2.fivemanage.com/C62CRnzCYRVd71OkMrHW0/weapon_microsmg.png',
            requiredRole: "1290301755711557663",
            cooldownHours: 24,
            contains: [
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'JonneS', value: 'jonnes', type: 'vehicle', rarity: 'rare', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/jonnes.png' },
                { name: 'Customkilpi', value: 'lisenceplate', type: 'vehicle', rarity: 'legendary', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/customkilpi.png' },
            ]
        },
        {
            name: 'VIP',
            value: 'vip',
            type: 'case',
            price: 500,
            image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/vipcase.png',
            requiredRole: 1293648241086169129,
            cooldownHours: 24,
            contains: [
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'Paska', value: 'paska', type: 'item', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/paska.png' },
                { name: 'JonneS', value: 'jonnes', type: 'vehicle', rarity: 'rare', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/jonnes.png' },
                { name: 'MONSU', value: 'wisedev-trailcat-littlemonster', type: 'vehicle', rarity: 'epic', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/wisedev-trailcat-littlemonster.png' },
                { name: 'G4M82', value: 'wisedev-g4m82', type: 'vehicle', rarity: 'epic', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/wisedev-g4m82.png' },
                { name: 'Helikopteri', value: 'buzzard2', type: 'vehicle', rarity: 'legendary', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/buzzard2.png' },
                { name: 'Customkilpi', value: 'lisenceplate', type: 'vehicle', rarity: 'legendary', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/customkilpi.png' },
            ]
        },
        {
            name: 'Ase Laatikko',
            value: 'asecase1',
            type: 'case',
            price: 250,
            image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/Case.png',
            requiredRole: null,
            contains: [
                { name: 'Vintage', value: 'weapon_vintagepistol', type: 'weapon', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_VINTAGEPISTOL.png' },
                { name: 'MK2', value: 'weapon_pistol_mk2', type: 'weapon', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_PISTOL_MK2.png' },
                { name: 'Pesäpallomaila', value: 'weapon_bat', type: 'weapon', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_BAT.png' },
                { name: 'Machete', value: 'weapon_machete', type: 'weapon', rarity: 'common', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_MACHETE.png' },
                { name: 'Pistol .50', value: 'weapon_pistol50', type: 'weapon', rarity: 'rare', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_PISTOL50.png' },
                { name: 'SNS Pistol', value: 'weapon_snspistol', type: 'weapon', rarity: 'rare', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_SNSPISTOL.png' },
                { name: 'Heavy Pistol', value: 'weapon_heavypistol', type: 'weapon', rarity: 'rare', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_HEAVYPISTOL.png' },
                { name: 'Assault SMG', value: 'weapon_assaultsmg', type: 'weapon', rarity: 'epic', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_ASSAULTSMG.png' },
                { name: 'Sniper Rifle', value: 'weapon_sniperrifle', type: 'weapon', rarity: 'epic', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_SNIPERRIFLE.png' },
                { name: 'Musket', value: 'weapon_musket', type: 'weapon', rarity: 'legendary', image: 'https://r2.fivemanage.com/IbOZSknqMLTbZZx6aBLiJ/WEAPON_MUSKET.png' },
            ]
        },
    ];
}
