R = {}

-- Essential config
R.Framework = "ESX" -- Options: ESX, qbcore, qbx
R.newESX = true -- if you use esx 1.1 version set this to false

R.CoreName = "es_extended" -- if you have renamed es_extended put the name here
R.Inventory = "ox_inventory" -- Options: ESX, qb-inventory, ox_inventory, quasar

-- target
R.UseTarget = false -- true if you use target
R.Target = "ox_target" -- options: ox_target, qb-target

-- Other
R.Debug = true

-- sql auto insert
R.EnableAutoinsert = true

-- Logs
R.Enablelogs = true -- set to true if you want to use logs

-- Command
R.GiveCreditCommand = "giveCredits" -- admin
R.OpenStoreCommand = "kauppa" -- user
R.ShowLicenseCommand = "lisenssi" -- user

-- Store Fast key
R.EnableFastKey = true
R.ToggleKey = "F4"

R.KeyText = "Avaa kauppa"

-- Money
R.MoneyCurrency = "bank" -- the currency you want money to come in

-- Notifys
R.EnablePurchaseNotifys = true

-- Test Drive
R.TestDriveTime = 1 -- in minutes
R.TestDriveCooldownTime = 5 -- in minutes
R.TestDrivePos = vector4(-1274.5339, -3389.3430, 13.9401, 329.8687)

-- Npc Settings
R.Ped = {
    Model = "g_m_m_armboss_01", -- model for the ped
    Scenario = "WORLD_HUMAN_AA_CLIPBOARD", -- scenario for the ped
    Location = vector4(-261.9832, -975.3669, 31.2197, 253.3460),
}

-- Blip settings
R.EnableBlip = false
R.BlipSettings = {
    Name = "Kauppa",
    Pos = vector3(-258.5634, -973.3538, 31.2200),
    Sprite = 59,
    Display = 4,
    Scale = 0.5,
    Colour = 15,
}

-- Discord settings
R.Discord = {
    Enabled = true,
}
