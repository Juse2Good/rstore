fx_version 'cerulean'
game 'gta5'
author 'Riisimies'
description 'https://r-scripts.net'
lua54 'yes'
version '1.0.1'

client_scripts {
	'client/cl_*.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
	'server/sv_*.lua',
}

shared_scripts {
	'@ox_lib/init.lua',
    'config.lua',
}

ui_page 'html/index.html'

files {
    'locales/*.json',
    'html/index.html',
    'html/css/*.css',
	'html/js/*.js',
}
