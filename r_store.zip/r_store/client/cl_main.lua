local open = false
local testdrive = false
local endingTestDrive = false
local oldPosition = nil
local testDriveCooldown = false
local cooldownTime = R.TestDriveCooldownTime * 60
local currentCar = nil

lib.locale()

CreateThread(function()
    if R.EnableBlip then
        local blip = AddBlipForCoord(R.BlipSettings.Pos.x, R.BlipSettings.Pos.y, R.BlipSettings.Pos.z)

        SetBlipSprite(blip, R.BlipSettings.Sprite)
        SetBlipDisplay(blip, R.BlipSettings.Display)
        SetBlipScale(blip, R.BlipSettings.Scale)
        SetBlipColour(blip, R.BlipSettings.Colour)
        SetBlipAsShortRange(blip, true)
        
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(R.BlipSettings.Name)
        EndTextCommandSetBlipName(blip)
    end
end)

function NearNpc(location, distance)
    local pos = GetEntityCoords(PlayerPedId())
    local dist = #(location - pos)

    return dist <= distance
end

CreateThread(function()
    local model_npc = R.Ped.Model
    
    RequestModel(model_npc)
    while not HasModelLoaded(model_npc) do
        Wait(10)
    end

    local npc_location = vector3(R.Ped.Location.x, R.Ped.Location.y, R.Ped.Location.z)
    local ped = CreatePed(7, model_npc, npc_location.x, npc_location.y, npc_location.z, R.Ped.Location.w, false, true)

    SetEntityCoordsNoOffset(ped, npc_location)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    TaskStartScenarioInPlace(ped, R.Ped.Scenario, 0, true)

    if R.UseTarget then
        CreateTarget(npc_location, "target_npc_store", 3.0, 'fas fa-store', locale("open_store"), function()
            return true
        end, function()
            ExecuteCommand(R.OpenStoreCommand)
        end)
    else
        local shown = false

        while true do
            local near = NearNpc(npc_location, 3.0)
    
            if near and not shown then
                lib.showTextUI("[E] - "..locale("open_store"), {
                    position = 'right-center',
                    icon = 'fas fa-bars',
                    style = {
                        borderRadius = 10,
                        backgroundColor = '#0a0a0a',
                    }
                })
    
                shown = true
            elseif not near and shown then
                lib.hideTextUI()
                shown = false
            end
    
            if shown and IsControlJustReleased(0, 38) then
                ExecuteCommand(R.OpenStoreCommand)
            end
    
            Wait(near and 5 or 500)
        end
    end
end)

RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    open = false
    cb({})
end)

RegisterCommand(R.ShowLicenseCommand, function()
    lib.notify({
        title = locale("storeLabel"),
        description = locale("LicenseCopied"),
        type = 'success'
    })

    local license = GetIdentifier()

    lib.setClipboard(license)
end)

RegisterCommand(R.OpenStoreCommand, function()
    if open then
        return
    end

    lib.callback.await("r_store:checkAndRegisterPlayer", nil)

    local coins = lib.callback.await("r_store:getPlayerCoinBalance", nil)

    open = true
    
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open_store',
        coins = coins,
    })
end)

if R.EnableFastKey then
    RegisterKeyMapping(R.OpenStoreCommand, R.KeyText, 'keyboard', R.ToggleKey)
end

RegisterNUICallback('getcoins', function(data, cb)
    local coinsAmount = lib.callback.await("r_store:getPlayerCoinBalance", nil)

    if coinsAmount then
        cb({ status = 'success', coins = coinsAmount })
    else
        cb({ status = 'error', message = 'Failed to fetch coins amount' })
    end
end)

RegisterNUICallback('purchase', function(data, cb)
    local totalCost = data.data.price * data.quantity

    local items = {
        name = data.data.name,
        type = data.data.type,
        value = data.data.value,
        amount = data.quantity,
    }

    local coinsAmount = lib.callback.await("r_store:getPlayerCoinBalance", nil)

    if coinsAmount >= totalCost then
        lib.callback.await("r_store:removeCoinsFromPlayer", nil, totalCost)
        lib.callback.await("r_store:addItemsToPlayer", nil, items)

        cb({ status = 'success' })
    else
        cb({ status = 'failed' })
    end
end)

RegisterNUICallback('startTestDrive', function(data, cb)
    if testDriveCooldown then
        lib.notify({
            title = locale("storeLabel"),
            description = locale("TestDriveCooldown"),
            type = 'error'
        })
        return cb({})
    end

    local ped = PlayerPedId()
    
    local vehicleModel = data.vehicleData.value
    local spawnLocation = R.TestDrivePos

    oldPosition = GetEntityCoords(ped)

    SetEntityCoords(ped, spawnLocation, false, false, false, true)
    currentCar = SpawnVehicle(vehicleModel, spawnLocation)

    StartTestDrive()
    CoolDown()

    cb({})
end)

RegisterNUICallback('removecasecoins', function(data, cb)
    local casePrice = data.casePrice
    local requiredRole = data.requiredRole
    local caseValue = data.caseValue
    local cooldownHours = data.cooldownHours

    local result = lib.callback.await("r_store:removeCaseCoins", nil, casePrice, requiredRole, caseValue, cooldownHours)

    if result.success then
        cb({ status = 'success', coins = result.coins })
    else
        cb({ status = 'error', message = result.message or 'Failed to remove coins' })
    end
end)

RegisterNUICallback('givecasereward', function(data, cb)
    local wonItem = data.wonItem

    local result = lib.callback.await("r_store:giveOpenCaseReward", nil, wonItem)

    if result.success then
        cb({ status = 'success', coins = result.coins })
    else
        cb({ status = 'error', message = result.message or 'Failed to give case reward' })
    end
end)

RegisterNUICallback('removecoinflipbet', function(data, cb)
    local betAmount = data.betAmount

    local result = lib.callback.await("r_store:removeCoinflipBet", nil, betAmount)

    if result.success then
        cb({ status = 'success', coins = result.coins })
    else
        cb({ status = 'error', message = result.message or 'Failed to remove bet' })
    end
end)

RegisterNUICallback('givecoinflipwinnings', function(data, cb)
    local betAmount = data.betAmount

    local result = lib.callback.await("r_store:giveCoinflipWinnings", nil, betAmount)

    if result.success then
        cb({ status = 'success', coins = result.coins })
    else
        cb({ status = 'error', message = result.message or 'Failed to give winnings' })
    end
end)

RegisterNUICallback('startmines', function(data, cb)
    local betAmount = data.betAmount
    local mineCount = data.mineCount

    local result = lib.callback.await("r_store:startMinesGame", nil, betAmount, mineCount)

    if result.success then
        cb({ status = 'success', coins = result.coins })
    else
        cb({ status = 'error', message = result.message or 'Failed to start mines game' })
    end
end)

RegisterNUICallback('cashoutmines', function(data, cb)
    local betAmount = data.betAmount
    local multiplier = data.multiplier
    local revealedCount = data.revealedCount

    local result = lib.callback.await("r_store:cashoutMines", nil, betAmount, multiplier, revealedCount)

    if result.success then
        cb({ status = 'success', coins = result.coins, winnings = result.winnings })
    else
        cb({ status = 'error', message = result.message or 'Failed to cashout' })
    end
end)

RegisterNUICallback('starttowergame', function(data, cb)
    local betAmount = data.betAmount
    local difficulty = data.difficulty or 'easy'

    local result = lib.callback.await("r_store:startTowerGame", nil, betAmount, difficulty)

    if result.success then
        cb({ status = 'success', coins = result.coins, eggPositions = result.eggPositions })
    else
        cb({ status = 'error', message = result.message or 'Failed to start tower game' })
    end
end)

RegisterNUICallback('cashouttower', function(data, cb)
    local betAmount = data.betAmount
    local multiplier = data.multiplier

    local result = lib.callback.await("r_store:cashoutTower", nil, betAmount, multiplier)

    if result.success then
        cb({ status = 'success', coins = result.coins, winnings = result.winnings })
    else
        cb({ status = 'error', message = result.message or 'Failed to cashout tower' })
    end
end)

RegisterNUICallback('getleaderboard', function(data, cb)
    local category = data.category

    local result = lib.callback.await("r_store:getLeaderboard", nil, category)

    if result then
        cb({ status = 'success', leaderboard = result })
    else
        cb({ status = 'error', message = 'Failed to fetch leaderboard' })
    end
end)

RegisterNUICallback('playsound', function(data, cb)
    local soundName = data.sound
    local soundSet = data.set or "HUD_FRONTEND_DEFAULT_SOUNDSET"

    PlaySoundFrontend(-1, soundName, soundSet, true)

    cb('ok')
end)

RegisterNUICallback('playkeno', function(data, cb)
    local betAmount = data.betAmount
    local selectedNumbers = data.selectedNumbers

    local result = lib.callback.await("r_store:playkeno", nil, betAmount, selectedNumbers)

    if result.success then
        cb({ status = 'success', coins = result.coins, drawnNumbers = result.drawnNumbers, hits = result.hits, winnings = result.winnings })
    else
        cb({ status = 'error', message = result.message or 'Failed to play keno' })
    end
end)

RegisterNUICallback('playdice', function(data, cb)
    local betAmount = data.betAmount
    local predictionType = data.predictionType
    local target = data.target

    local result = lib.callback.await("r_store:playdice", nil, betAmount, predictionType, target)

    if result.success then
        cb({ status = 'success', coins = result.coins, dice1 = result.dice1, dice2 = result.dice2, sum = result.sum, won = result.won, winnings = result.winnings })
    else
        cb({ status = 'error', message = result.message or 'Failed to play dice' })
    end
end)

function StartTestDrive()
    local aika = R.TestDriveTime * 60

    testdrive = true

	CreateThread(function()
		while aika > 0 do
			Wait(1000)

			if aika > 0 then
				aika = aika - 1
			end
		end
	end)

	CreateThread(function()
		while true do
            DisableControlAction(0, 75,  true)
			DisableControlAction(27, 75, true)

			Wait(0)

            lib.showTextUI(locale("StopTest", aika), {
                position = "right-center",
                icon = 'fas fa-clock',
                style = {
                    borderRadius = 4,
                    backgroundColor = '#141517',
                    color = 'white'
                }
            })

            if IsControlJustPressed(0, 38) then
                lib.hideTextUI()
                testDriveEnd()

                return
            end

            if aika == 0 then
                lib.hideTextUI()
                testDriveEnd()

                return
            end
		end
        
		lib.hideTextUI()
	end)
end

function testDriveEnd()
    if endingTestDrive then
        return
    end

    endingTestDrive = true

    local ped = PlayerPedId()

    if not testdrive then
        endingTestDrive = false
        return
    end

    local car = GetVehiclePedIsIn(ped)

    if DoesEntityExist(car) then
        DeleteEntity(car)
    else
        DeleteEntity(currentCar)
    end

    SetEntityCoords(ped, oldPosition, false, false, false, true)
    FreezeEntityPosition(ped, false)
    SetEntityVisible(ped, true)

    testdrive = false
    endingTestDrive = false
end

function CoolDown()
    testDriveCooldown = true

    CreateThread(function()
        local cooldownTimer = cooldownTime

        while cooldownTimer > 0 do
            Wait(1000)
            cooldownTimer = cooldownTimer - 1
        end

        testDriveCooldown = false
    end)
end
