local Core = nil

CreateThread(function()
    if R.Framework == "ESX" then
        if R.newESX then
            Core = exports[R.CoreName]:getSharedObject()
        else
            while Core == nil do
                TriggerEvent("esx:getSharedObject", function(obj) Core = obj end)
                
                Wait(100)
            end
        end
    else
        Core = exports["qb-core"]:GetCoreObject()
    end
end)

function GetIdentifier()
    local Identifier
    
    if R.Framework == "ESX" then
        Identifier = Core.PlayerData.identifier
    else
        Identifier = Core.Functions.GetPlayerData().citizenid
    end
    
    return Identifier
end

function SpawnVehicle(model, Coords)
    local spawnCallback = function(vehicle)
        SetVehicleEngineOn(vehicle, true, true)
        TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
    end

    local coords = vector3(Coords.x, Coords.y, Coords.z)
    
    local car 
    if R.Framework == "ESX" then
        Core.Game.SpawnVehicle(model, coords, Coords.w, function(vehicle)
            spawnCallback(vehicle)
            car = vehicle
        end)
    else
        Core.Functions.SpawnVehicle(model, function(vehicle)
            spawnCallback(vehicle)

            SetEntityHeading(vehicle, Coords.w)
            car = vehicle
        end, coords)
    end

    return car
end

function CreateTarget(coords, name, distance, icon, label, canInteractFunc, onSelectFunc)
    if R.Target == "ox_target" then
        exports.ox_target:addBoxZone({
            coords = coords,
            options = {
                {
                    name = name,
                    distance = distance,
                    icon = icon,
                    label = label,
                    canInteract = canInteractFunc,
                    onSelect = onSelectFunc
                }
            }
        })
    else
        exports["qb-target"]:AddBoxZone(name, coords, 2.45, 2.35, {
            name = name,
            heading = 170.30,
            minZ = 1.77834,
            maxZ = 140.87834,
            debugPoly = false,
        }, {
            options = {
                {
                    type = "client",
                    icon = icon,
                    label = label,
                    canInteract = canInteractFunc,
                    action = onSelectFunc
                },
            },
            distance = distance
        })
    end
end
